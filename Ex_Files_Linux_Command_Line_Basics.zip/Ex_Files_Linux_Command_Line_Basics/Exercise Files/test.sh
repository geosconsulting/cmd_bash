#!/usr/bin/bash
echo -e "\t\t\e[92mHello from the Test Script!\e[39m"
